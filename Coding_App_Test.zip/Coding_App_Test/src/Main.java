import java.io.*;
import java.util.Scanner;



public class Main {

    public static void main(String[] args) {
        Account A;
        A = new Account();

        Scanner reader = new Scanner(System.in);
        boolean negative= true;
        int user=1 ;
        while (user!= 2) {
            System.out.println("What would you like to do today?");
            System.out.println("1. Deposit\n2. Withdrawal\n3. View Balance\n");
            int response = reader.nextInt();
            if (response == 1) {
                System.out.println("How much would you like to Deposit today?\n");
                double Amount = reader.nextDouble();
                A.set_Deposit(Amount);
                System.out.print("Current balance: ");
                System.out.println(A.getAccount_Balance());
            }
            if (response == 2) {
                while (negative) {
                    System.out.println("How much would you like to Withdraw today?\n");
                    double Amount = reader.nextDouble();
                    if (Amount > A.getAccount_Balance()) {
                        System.out.println("That amount exceeds your current balance.");
                    }
                    else {
                        A.set_Withdraw(Amount);
                        negative=false;
                    }
                    System.out.print("Current balance: ");
                    System.out.println(A.getAccount_Balance());
                }
            }

            if (response == 3) {
                System.out.print("Current balance: ");
                System.out.println(A.getAccount_Balance());
            }
            System.out.println("Is there something else you would like to do today?\n1. Yes\n2. No");
            user= reader.nextInt();
        }
    }
}
