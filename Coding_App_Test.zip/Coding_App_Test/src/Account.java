public class Account {
    private Double Account_Balance=0.00;


    public void set_Deposit(Double Deposit) {
        Account_Balance = Account_Balance + Deposit;
    }

    public void set_Withdraw (Double Withdraw)
    {
        Account_Balance = Account_Balance - Withdraw;
    }

    public Double getAccount_Balance()
    {
        return Account_Balance;
    }
}

