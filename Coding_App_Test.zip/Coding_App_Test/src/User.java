public class User {

    private String user;
    public String getUser()
    {
        return user;
    }

    public void setUser(String name)
    {
        user= name;
    }


}
